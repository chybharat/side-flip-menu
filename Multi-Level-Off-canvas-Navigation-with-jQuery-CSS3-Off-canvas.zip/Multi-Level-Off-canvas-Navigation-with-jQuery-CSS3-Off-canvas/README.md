# off-canvas navigation pattern

This is a simple responsive off-canvas navigation pattern built with SASS, using CSS3 animations and a little bit of jQuery.

Demo: http://rafaelbirkmann.de/lab/off-canvas/

![Preview](https://github.com/Refugee/off-canvas/blob/master/preview.png?raw=true)